import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;

public class ReverseFile {

    public static void reverseContent(InputStream input, OutputStream output) throws IOException {
        StringBuilder content = new StringBuilder();
        int value;
        while ((value = input.read()) != -1) {
            content.append((char) value);
        }
        String reverseContent = content.reverse().toString();
        output.write(reverseContent.getBytes());
    }

    public static void reverseFileText(File input, File output) throws IOException {
        try (FileInputStream inputValue = new FileInputStream(input);
             FileOutputStream outputValue = new FileOutputStream(output)) {
            reverseContent(inputValue, outputValue);
        }
    }

    public static void main(String[] args) {
        try {
            File inputFile = new File("input.txt");
            File outputFile = new File("output.txt");

            reverseFileText(inputFile, outputFile);

            String output = Files.readString(outputFile.toPath());
            System.out.println("Reversed content: " + output);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
