import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class ReverseFileTest {

    public static void main(String[] args) {
        testReverseContent();
    }

    public static void testReverseContent() {
        String input = "ABC";
        String expectedOutput = "CBA";

        try {
            ByteArrayInputStream inputStream = new ByteArrayInputStream(input.getBytes());
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

            ReverseFile.reverseContent(inputStream, outputStream);

            String actualOutput = outputStream.toString();
            assert expectedOutput.equals(actualOutput) : "Test failed: expected '" + expectedOutput + "', but got '" + actualOutput + "'";

            System.out.println("Test passed: '" + input + "' reversed to '" + actualOutput + "'");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
